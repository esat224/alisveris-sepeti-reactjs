export const sepeteEkle = (book) => {
  // id'sine göre spete ekleyeceğiz.(değiştirdik book bilgilerini göre spete ekliyoruz.)
  // sepeteEkle, action creator'dür. bir fonksiyodundur.
  // action creator'ümüz de bize action döndürür.
  // action da bir objedir.

  // action objemizi tanımlıyoruz.
  return { type: "SEPETE_EKLE", payload: book };
  // actionumuz çağırıldığjnda dispatch sayesinde reducer'a gönderecek.
};
