import { data } from "../data";

const INITIAL_STATE = {
  bookList: data,
  cart: []
};

// reducer bir fonksiyondur.
// Parametre olarak state ve action alır
// state'yi geriye döndürür.

// uygulama ilk açıldığında INITIAL_STATE değeri ile başlayacak.

export const reducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case "SEPETE_EKLE":
      return { ...state, cart: [...state.cart, action.payload] };
    // ...state: state'yi açıyor hepsini döndürüyor,
    // cart: [...state.cart: cart'ın içine cart'ın hepsini açıyor
    // action.payload:  yeni bekeln kitap cart'a ekliyor.
    default:
      return state;
  }
};
