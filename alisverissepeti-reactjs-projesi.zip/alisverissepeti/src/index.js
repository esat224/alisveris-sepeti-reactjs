import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router } from "react-router-dom";
import App from "./App";
import { Provider } from "react-redux";

import { reducer } from "./reducers/index";

// ilk yapmamız geerek store oluşturmak.
import { createStore } from "redux";

const store = createStore(reducer);
// store'muz reducer'imizi parametre olarak alıyor.
// reducer'i ayrı bir dosyada oluşturuyoruz.

// uygulamamızın en üst seviyesini provider ile sarmamız gerekiyor.
// Çünkü bütün komponentlerin store'a ulaşmasını istiyorum.
// bunu da üstte import ettik.

const rootElement = document.getElementById("root");
ReactDOM.render(
  <React.StrictMode>
    {/* provider store adında attribute oluşuturuyoruz. 
    Store ismindeki parametreye yukarıda oluşturuduğumuz store  */}
    <Provider store={store}>
      <Router>
        <App />
      </Router>
    </Provider>
  </React.StrictMode>,
  rootElement
);
